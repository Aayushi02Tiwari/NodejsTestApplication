const http = require('http');
const debug = require('debug')('node-angular');
const app = require('./backend/app');

var port = process.env.PORT || 3000;
app.set(port);

var server = http.createServer(app);
server.listen(port);